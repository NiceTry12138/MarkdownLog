// Copyright Epic Games, Inc. All Rights Reserved.

#include "HTTPObjectStorageClient.h"
#include "SimpleHttpManage.h"
#include "RequiredProgramMainCPPInclude.h"
#include "SimpleHTTPType.h"
#include "HTTPObjectStorageClientLog.h"
#include "HTTPObjectStorageClientMethod.h"

using namespace HTTPObjectStorageClientMethod;

#if PLATFORM_WINDOWS
#pragma optimize("",off) 
#endif

IMPLEMENT_APPLICATION(HTTPObjectStorageClient, "HTTPObjectStorageClient");

INT32_MAIN_INT32_ARGC_TCHAR_ARGV()
{
	GEngineLoop.PreInit(ArgC, ArgV);
	UE_LOG(LogHTTPObjectStorageClient, Display, TEXT("Hello World"));
	
	//账户
	FString Code = GetParseValue(TEXT("-Code="));
	FString Bucket = GetParseValue(TEXT("-Bucket="));
	FString PatchVersionLogName = GetParseValue(TEXT("-PatchVersionLogName="));
	FString ServerVersionName = GetParseValue(TEXT("-ServerVersionName="));
	FString VersionLock = GetParseValue(TEXT("-VersionLock="));
	FString Platform = GetParseValue(TEXT("-platform="));
	FString PakLocalPaths = GetParseValue(TEXT("-PakLocalPaths="));
	FString Endpoint = GetParseValue(TEXT("-Endpoint="));

	/*
	-AccessKeyId=LTAI4GKLH9HPGM1rbcL3JcY6 
	-AccessKeySecret=xxx 
	-Endpoint=oss-cn-shanghai.aliyuncs.com 
	-Bucket=osss-erver-test 
	-PatchVersionLogName=Version/VersionLog.con 
	-ServerVersionName=Version/ServerVersion.con 
	-VersionLock=Version/MutexVersion.con 
	-platform=windows 
	-PakLocalPaths=P:/ReHotUpdate/Save/Pak/
	*/

	//测试
	//FSimpleHTTPResponseDelegate Delegate;
	//FString URL = TEXT("http://192.168.31.137");
	//FString Save = FPaths::ProjectDir() / TEXT("wordpress-5.7.2.zip");
	//SIMPLE_HTTP.GetObjectToLocal(Delegate, URL/TEXT("wordpress-5.7.2.zip"), Save);
	//FString LocalAsset = FPaths::ConvertRelativePathToFull( FPaths::ProjectDir() / TEXT("xxx1.zip"));

	//SIMPLE_HTTP.PutObjectFromLocal(Delegate, URL / TEXT("xxx1.zip"), LocalAsset);

	if (Code.Equals(TEXT("UnLock")))
	{
		//解锁
		HTTPObjectStorageClientMethod::HTTPServerUnLock([](bool)
		{
			UE_LOG(LogHTTPObjectStorageClient, Display, TEXT("-------------Server unlock-----------"));
			exit(0);
		});
	}
	else if (Code.Equals(TEXT("")))
	{
		//服务器版本
		FVersion Version;

		auto PUTFunction = [&]()
		{
			UE_LOG(LogHTTPObjectStorageClient, Display, TEXT("Hello World!!!!!!!"));

			CheckHTTPServerLock(
			[&](bool bLock)
			{
				UE_LOG(LogHTTPObjectStorageClient, Display, TEXT("%i"), bLock);
				if (bLock)
				{
					UE_LOG(LogHTTPObjectStorageClient, Display, TEXT("The http server is currently used by other operators."));
					exit(23);
				}
				else
				{
					HTTPServerLock([&](bool)
					{	
						UE_LOG(LogHTTPObjectStorageClient, Display, TEXT("-------------Server lock-----------"));
						GetHTTPServerVersion([&](const FString &Msg)
						{
							if (Msg != TEXT("Error"))
							{
								SimpleVersionControl::Read(Msg, Version);
							}

							//创建新版本
							Version.Crc = FGuid::NewGuid().ToString();

							FString URL = TEXT("http://") + Endpoint / Bucket / Platform /TEXT("Version/Patch");

							FSimpleHTTPResponseDelegate Delegate;

							//单个对象上传成功
							Delegate.SimpleCompleteDelegate.BindLambda(
							[&](const FSimpleHttpRequest& InHttpRequest, const FSimpleHttpResponse& InHttpResponse, bool bLink)
							{
								if (bLink)
								{
									bool bExists = false;
									FString PatchName = FPaths::GetCleanFilename(InHttpRequest.URL);

									FRemoteDataDescribe Describe;
									FRemoteDataDescribe* RemoteDataDescribe = &Describe;
									for (auto& TmpVersion : Version.Content)
									{
										FString LinkName = FPaths::GetCleanFilename(TmpVersion.Link);
										if (LinkName == PatchName)
										{
											RemoteDataDescribe = &TmpVersion;
											bExists = true;
											break;
										}
									}

									RemoteDataDescribe->Len = InHttpRequest.ContentLength;
									RemoteDataDescribe->Crc = FGuid::NewGuid().ToString();
									RemoteDataDescribe->Link = InHttpRequest.URL;
								
									if (!bExists)
									{
										Version.Content.Add(*RemoteDataDescribe);
									}
								}
							});

							//所有对象上传成功 上传版本信息
							Delegate.AllTasksCompletedDelegate.BindLambda([&]()
							{
								HTTPObjectStorageClientMethod::PutServerVersion(Version, [](bool bLink)
								{
									if (bLink)
									{

									}

									//解锁
									HTTPObjectStorageClientMethod::HTTPServerUnLock([](bool)
									{
										UE_LOG(LogHTTPObjectStorageClient, Display, TEXT("-------------Server unlock-----------"));
										exit(0);
									});
								});
							});

							SIMPLE_HTTP.PutObjectsFromLocal(Delegate, URL,PakLocalPaths);
						});
					});
				}
			});
		};

		HTTPObjectStorageClientInit(PUTFunction);
	}
	double LastTime = FPlatformTime::Seconds();
	for (;;)
	{
		FPlatformProcess::Sleep(0.03f);
		double Now = FPlatformTime::Seconds();
		float DeltaSenconds = Now - LastTime;
		FSimpleHttpManage::Get()->Tick(DeltaSenconds);

		LastTime = Now;
	}

	FEngineLoop::AppExit();
	return 0;
}

#if PLATFORM_WINDOWS
#pragma optimize("",on) 
#endif