// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

const FString HTTPServerScriptPathName = TEXT("Script/ServerScript.php");