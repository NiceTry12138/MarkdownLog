#include "../../Public/Pak/UnrealPakFile.h"
#include "Settings/SimpleUnrealPakSettingsEditor.h"
#include "Misc/App.h"
#include "Misc/FileHelper.h"

namespace SimpleUnrealPakEditor
{
	FString ConvertPlatformToString(EUnrealPakSettingsPlatform Platform)
	{
		switch (Platform)
		{
		case EUnrealPakSettingsPlatform::Windows:
			return TEXT("Windows");
		case EUnrealPakSettingsPlatform::Linux:
			return TEXT("Linux");
		case EUnrealPakSettingsPlatform::Mac:
			return TEXT("Mac");
		case EUnrealPakSettingsPlatform::Android:
			return TEXT("Android");
		case EUnrealPakSettingsPlatform::iOS:
			return TEXT("iOS");
		case EUnrealPakSettingsPlatform::HTML5:
			return TEXT("HTML5");
		}

		return "Windows";
	}

	void CreateAssetText(const TArray<FString>& ContentAssetPaths, FString& AssetString, bool bCook = true)
	{
		FString EngineDir = FPaths::ConvertRelativePathToFull(FPaths::EngineContentDir());
		FString ProjectDir = FPaths::ConvertRelativePathToFull(FPaths::ProjectDir());

		auto IsDir = [](const FString& ConstTmpPaths, const FString& String) ->bool
		{
			return ConstTmpPaths.Find(String) >= 0;
		};

		auto ReplaceContent = [&AssetString](const FString& ConstTmpPaths, const FString& CookContent, const FString& Extenstion, bool bEngine = false)
		{
			FString UAssetPaths = ConstTmpPaths.Replace(
				*(bEngine ? FPaths::ConvertRelativePathToFull(FPaths::RootDir()) : FPaths::ConvertRelativePathToFull(FPaths::ProjectDir())),
				*CookContent);

			FString UExpPaths = UAssetPaths.Replace(*Extenstion, TEXT(".uexp"));
			if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*UExpPaths))
			{
				AssetString += UExpPaths + TEXT("\r\n");
			}

			FString UbulkPaths = UAssetPaths.Replace(*Extenstion, TEXT(".ubulk"));
			if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*UbulkPaths))
			{
				AssetString += UbulkPaths + TEXT("\r\n");
			}
		};

		for (const auto& ConstTmpPaths : ContentAssetPaths)
		{
			if (bCook)
			{
				FString GameCookContent = ProjectDir + FString(TEXT("Saved/Cooked/Windows")) / FApp::GetProjectName() / TEXT("");
				FString EngineCookContent = ProjectDir + TEXT("Saved/Cooked/Windows/");
			
				FString Extenstion = FPaths::GetExtension(ConstTmpPaths, true);
				if (IsDir(ConstTmpPaths, EngineDir))
				{
					ReplaceContent(ConstTmpPaths, EngineCookContent, Extenstion, true);
				}
				else if (IsDir(ConstTmpPaths, ProjectDir))
				{
					ReplaceContent(ConstTmpPaths, GameCookContent, Extenstion);
				}
				else
				{
					check(0);
				}
			}
			else
			{
				AssetString += ConstTmpPaths + TEXT("\r\n");
			}
		}
	}

	bool GeneratedPak(const TArray<FString>& ContentAssetPaths, const FString& ConstTmpPaths)
	{
		FString SavePakFile = GetDefault<USimpleUnrealPakSettingsEditor>()->PakSavePaths.Path;

		//�������ǵ���Դ��
		FString AssetString;
		CreateAssetText(ContentAssetPaths,AssetString, GetDefault<USimpleUnrealPakSettingsEditor>()->bCooked);
		FString AssetStringPaths = FPaths::ProjectSavedDir() / TEXT("AssetPaths") / FGuid::NewGuid().ToString() + TEXT(".txt");
		FFileHelper::SaveStringToFile(AssetString, *AssetStringPaths, FFileHelper::EEncodingOptions::ForceUTF8);

		FString UnrealPakExePaths = FPaths::ConvertRelativePathToFull(FPaths::EngineDir()) + TEXT("Binaries/Win64/UnrealPak.exe");
		FString PakNamePaths = SavePakFile / FPaths::GetCleanFilename(ConstTmpPaths) + TEXT(".pak ");

		//�Ƿ�ѹ��
		FString CompressParm = "";
		if (GetDefault<USimpleUnrealPakSettingsEditor>()->bCompress)
		{
			CompressParm = TEXT(" -compress");
		}

		//�Ƿ�AES����
		FString AESParm = "";
		if (GetDefault<USimpleUnrealPakSettingsEditor>()->bAES)
		{
			AESParm = TEXT(" -encrypt -encryptindex -aes=") + GetDefault<USimpleUnrealPakSettingsEditor>()->AES.ToString();
		}

		//�����ʽ
		FString UTF8Parm = "";
		if (GetDefault<USimpleUnrealPakSettingsEditor>()->bForceUTF8)
		{
			UTF8Parm = TEXT(" -UTF8Output");
		}

		//log
		FString AbslogParm = "";
		{
			AbslogParm = TEXT(" -abslog=") + GetDefault<USimpleUnrealPakSettingsEditor>()->PakLogPaths.Path / TEXT("SimpleUnrealPakLog.txt");
		}

		FString OrderParm = "";
		if (GetDefault<USimpleUnrealPakSettingsEditor>()->bOrder)
		{
			OrderParm = TEXT(" -installed -order=") + FPaths::ProjectDir() / TEXT("Build/Windows/FileOpenOrder/CookerOpenOrder.log");
		}

		//���ƽ̨
		FString PakPlatformParam = TEXT(" -platform=") + ConvertPlatformToString(GetDefault<USimpleUnrealPakSettingsEditor>()->PakPlatform);

		//���������ļ���
		FString CreateParm = PakNamePaths + TEXT("-create=") + AssetStringPaths + AESParm + AbslogParm + CompressParm + UTF8Parm + PakPlatformParam + OrderParm + TEXT(" -multiprocess -patchpaddingalign=2048");

		FProcHandle Handle = FPlatformProcess::CreateProc(*UnrealPakExePaths,*CreateParm, false, false, false, nullptr, 0, nullptr, nullptr);
		FPlatformProcess::WaitForProc(Handle);

		return true;
	}

	bool FPak::PakFile(const TArray<FString>& InPaths)
	{
		for (auto &Tmp : InPaths)
		{
			FString CoypeTmpPaths = Tmp;
			if (CoypeTmpPaths.RemoveFromStart(TEXT("/Game/")))
			{
				CoypeTmpPaths = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir()) / CoypeTmpPaths;

				//Ѱ�Ҹ��ļ��µ��������ļ�
				TArray<FString> ContentAssetPaths;
				IFileManager::Get().FindFilesRecursive(ContentAssetPaths, *CoypeTmpPaths, TEXT("*"), true, false);
			
				if (!GeneratedPak(ContentAssetPaths, Tmp))
				{

					return false;
				}
			}
		}

		return true;
	}
}

