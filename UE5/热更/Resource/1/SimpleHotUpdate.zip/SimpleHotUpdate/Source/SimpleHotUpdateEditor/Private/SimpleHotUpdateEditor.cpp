// Copyright Epic Games, Inc. All Rights Reserved.

#include "SimpleHotUpdateEditor.h"
#include "SimpleHotUpdateEditorStyle.h"
#include "SimpleHotUpdateEditorCommands.h"
#include "LevelEditor.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "ToolMenus.h"
#include "ContentBrowserModule.h"
#include "Pak/UnrealPakFile.h"
#include "ISettingsModule.h"
#include "Settings/SimpleUnrealPakSettingsEditor.h"

static const FName SimpleHotUpdateEditorTabName("SimpleHotUpdateEditor");

#define LOCTEXT_NAMESPACE "FSimpleHotUpdateEditorModule"

void FSimpleHotUpdateEditorModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	
	FSimpleHotUpdateEditorStyle::Initialize();
	FSimpleHotUpdateEditorStyle::ReloadTextures();

	FSimpleHotUpdateEditorCommands::Register();
	
	PluginCommands = MakeShareable(new FUICommandList);

	PluginCommands->MapAction(
		FSimpleHotUpdateEditorCommands::Get().OpenPluginWindow,
		FExecuteAction::CreateRaw(this, &FSimpleHotUpdateEditorModule::PluginButtonClicked),
		FCanExecuteAction());

	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FSimpleHotUpdateEditorModule::RegisterMenus));
	
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(SimpleHotUpdateEditorTabName, FOnSpawnTab::CreateRaw(this, &FSimpleHotUpdateEditorModule::OnSpawnPluginTab))
		.SetDisplayName(LOCTEXT("FSimpleHotUpdateEditorTabTitle", "SimpleHotUpdateEditor"))
		.SetMenuType(ETabSpawnerMenuType::Hidden);

	//�ļ���
	FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
	TArray<FContentBrowserMenuExtender_SelectedPaths>& ContentBrowserMenuExtender_SelectedPaths = ContentBrowserModule.GetAllPathViewContextMenuExtenders();
	ContentBrowserMenuExtender_SelectedPaths.Add(FContentBrowserMenuExtender_SelectedPaths::CreateRaw(this,&FSimpleHotUpdateEditorModule::OnExtendContentBrowser));

	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>(TEXT("Settings")))
	{
		SettingsModule->RegisterSettings("Project", "ProjectPak", "PakSettings",
			LOCTEXT("SimpleUnrealPakSettings", "Pak Settings"), 
			LOCTEXT("SimpleUnrealPakSettingsTip", "Package settings for the current platform you have set."),
			GetMutableDefault<USimpleUnrealPakSettingsEditor>());
	}
}

void FSimpleHotUpdateEditorModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.

	UToolMenus::UnRegisterStartupCallback(this);

	UToolMenus::UnregisterOwner(this);

	FSimpleHotUpdateEditorStyle::Shutdown();

	FSimpleHotUpdateEditorCommands::Unregister();

	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(SimpleHotUpdateEditorTabName);
}

TSharedRef<SDockTab> FSimpleHotUpdateEditorModule::OnSpawnPluginTab(const FSpawnTabArgs& SpawnTabArgs)
{
	FText WidgetText = FText::Format(
		LOCTEXT("WindowWidgetText", "Add code to {0} in {1} to override this window's contents"),
		FText::FromString(TEXT("FSimpleHotUpdateEditorModule::OnSpawnPluginTab")),
		FText::FromString(TEXT("SimpleHotUpdateEditor.cpp"))
		);

	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			// Put your tab content here!
			SNew(SBox)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
				.Text(WidgetText)
			]
		];
}

void FSimpleHotUpdateEditorModule::PluginButtonClicked()
{
	FGlobalTabmanager::Get()->TryInvokeTab(SimpleHotUpdateEditorTabName);
}

TSharedRef<FExtender> FSimpleHotUpdateEditorModule::OnExtendContentBrowser(const TArray<FString>& NewPaths)
{
	TSharedRef<FExtender> Extender(new FExtender);

	Extender->AddMenuExtension("FolderContext", EExtensionHook::Before,NULL, FMenuExtensionDelegate::CreateRaw(this,&FSimpleHotUpdateEditorModule::CreateSuMenuForContentBrowser, NewPaths));

	return Extender;
}

void FSimpleHotUpdateEditorModule::CreateSuMenuForContentBrowser(FMenuBuilder& MunuBuilder, TArray<FString> NewPaths)
{
	MunuBuilder.AddSubMenu(
		LOCTEXT("HotUpdateEditor", "Push to Server"),
		LOCTEXT("HotUpdateEditorDescribe", "Upload data to the server ."),
		FNewMenuDelegate::CreateRaw(this,&FSimpleHotUpdateEditorModule::SubExtendContentBrowser, NewPaths));
}

void FSimpleHotUpdateEditorModule::SubExtendContentBrowser(FMenuBuilder& MunuBuilder, TArray<FString> NewPaths)
{
	MunuBuilder.BeginSection("HotUpdate", LOCTEXT("HotUpdateMenu", "Upload server mode"));

	MunuBuilder.AddMenuEntry(
		LOCTEXT("HotUpdate_Push", "Push"),
		LOCTEXT("HotUpdate_PushTip", "Push resources to the server."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateRaw(this, &FSimpleHotUpdateEditorModule::Push,NewPaths)));

	MunuBuilder.EndSection();
}

void FSimpleHotUpdateEditorModule::Push(TArray<FString> NewPaths)
{
	if (SimpleUnrealPakEditor::FPak().PakFile(NewPaths))
	{

	}
}

void FSimpleHotUpdateEditorModule::RegisterMenus()
{
	// Owner will be used for cleanup in call to UToolMenus::UnregisterOwner
	FToolMenuOwnerScoped OwnerScoped(this);

	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Window");
		{
			FToolMenuSection& Section = Menu->FindOrAddSection("WindowLayout");
			Section.AddMenuEntryWithCommandList(FSimpleHotUpdateEditorCommands::Get().OpenPluginWindow, PluginCommands);
		}
	}

	{
		UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar");
		{
			FToolMenuSection& Section = ToolbarMenu->FindOrAddSection("Settings");
			{
				FToolMenuEntry& Entry = Section.AddEntry(FToolMenuEntry::InitToolBarButton(FSimpleHotUpdateEditorCommands::Get().OpenPluginWindow));
				Entry.SetCommandList(PluginCommands);
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FSimpleHotUpdateEditorModule, SimpleHotUpdateEditor)