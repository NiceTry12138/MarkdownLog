#include "Settings/SimpleUnrealPakSettingsEditor.h"
#include "HAL/PlatformFilemanager.h"
#include "Misc/Paths.h"
#include "GenericPlatform/GenericPlatformFile.h"

USimpleUnrealPakSettingsEditor::USimpleUnrealPakSettingsEditor()
	:Super()
{
	auto ResetPath = [](FString &InPath,const TCHAR *InNewPath)
	{
		IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
		InPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir() / InNewPath);
		if (!PlatformFile.DirectoryExists(*InPath))
		{
			PlatformFile.CreateDirectory(*InPath);
		}
	};

	ResetPath(PakSavePaths.Path, TEXT("Pak"));
	ResetPath(PakLogPaths.Path, TEXT("PakLog"));
	PakPlatform = EUnrealPakSettingsPlatform::Windows;
	bCompress = true;
	bForceUTF8 = true;
	bAES = false;
	bOrder = false;
}