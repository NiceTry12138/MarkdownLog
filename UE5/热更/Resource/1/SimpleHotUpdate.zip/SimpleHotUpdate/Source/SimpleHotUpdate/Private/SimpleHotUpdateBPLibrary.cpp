// Copyright Epic Games, Inc. All Rights Reserved.

#include "SimpleHotUpdateBPLibrary.h"
#include "SimpleHotUpdate.h"

USimpleHotUpdateBPLibrary::USimpleHotUpdateBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

float USimpleHotUpdateBPLibrary::SimpleHotUpdateSampleFunction(float Param)
{
	return -1;
}

