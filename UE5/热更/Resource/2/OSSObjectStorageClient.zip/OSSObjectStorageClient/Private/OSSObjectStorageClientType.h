// Copyright (C) RenZhai.2020.All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

enum EOSSLockType
{
	OSS_CONNECTION_FAILED,
	OSS_FALSE,
	OSS_TRUE,
	OSS_UNKNOWN_ERROR,
};
