// Copyright Epic Games, Inc. All Rights Reserved.


#include "OSSObjectStorageClient.h"

#include "RequiredProgramMainCPPInclude.h"
#include "SimpleOSSManage.h"
#include "OSSObjectStorageClientMacro.h"

DEFINE_LOG_CATEGORY_STATIC(LogOSSObjectStorageClient, Log, All);

IMPLEMENT_APPLICATION(OSSObjectStorageClient, "OSSObjectStorageClient");

INT32_MAIN_INT32_ARGC_TCHAR_ARGV()
{
	GEngineLoop.PreInit(ArgC, ArgV);
	UE_LOG(LogOSSObjectStorageClient, Display, TEXT("Hello World"));

	auto GetParseValue = [](const FString &InKey)->FString
	{
		FString Value;
		if (!FParse::Value(FCommandLine::Get(),*InKey, Value))
		{
			UE_LOG(LogOSSObjectStorageClient, Error, TEXT("%s was not found value"),*InKey);
		}

		return Value;
	};

	//账户
	FString AccessKeyId = GetParseValue(TEXT("-AccessKeyId="));
	FString AccessKeySecret = GetParseValue(TEXT("-AccessKeySecret="));
	FString Endpoint = GetParseValue(TEXT("-Endpoint="));

	FString Bucket = GetParseValue(TEXT("-Bucket="));
	FString PatchVersionLogName = GetParseValue(TEXT("-PatchVersionLogName="));
	FString ServerVersionName = GetParseValue(TEXT("-ServerVersionName="));
	FString VersionLock = GetParseValue(TEXT("-VersionLock="));
	FString Platform = GetParseValue(TEXT("-platform="));
	FString PakLocalPaths = GetParseValue(TEXT("-PakLocalPaths="));

	//账户初始化
	SIMPLE_OSS.InitAccounts(AccessKeyId, AccessKeySecret, Endpoint);

	if (SIMPLE_OSS.DoesBucketExist(Bucket))
	{
		CHECK_OSS_LOCK_STATUS(1,Bucket, VersionLock, Platform,);

		if (Bucket.Len() && PakLocalPaths.Len())
		{
			FVersion Version;
			OSSObjectStorageClientMethod::GetServerVersion(Bucket, ServerVersionName, Platform, Version);
		
			//判断版本是否一样 如果一样代表热更新 不一样代表有新版本上传
			Version.Crc = FGuid::NewGuid().ToString();

			FString URL = TEXT("https:/") / Bucket + TEXT(".") + SIMPLE_OSS.GetEndpoint();
		
			auto UpdateNewData = [&](const FString& NewPath)
			{
				if (!NewPath.IsEmpty())
				{
					bool bExists = false;

					FString PatchName = FPaths::GetCleanFilename(NewPath);
					
					FRemoteDataDescribe Describe;
					FRemoteDataDescribe* RemoteDataDescribe = &Describe;
					for (auto& TmpVersion : Version.Content)
					{
						FString LinkName = FPaths::GetCleanFilename(TmpVersion.Link);
						if (LinkName == PatchName)
						{
							RemoteDataDescribe = &TmpVersion;
							bExists = true;
							break;
						}
					}

					//大小
					{
						TArray<uint8> DataInstance;
						FFileHelper::LoadFileToArray(DataInstance, *NewPath);
						RemoteDataDescribe->Len = DataInstance.Num();
					}

					RemoteDataDescribe->Crc = FGuid::NewGuid().ToString();

					FString ObjectName = Platform / TEXT("Patch") / PatchName;

					if (SIMPLE_OSS.PutObject(Bucket, FPaths::ConvertRelativePathToFull(NewPath), ObjectName))
					{
						RemoteDataDescribe->Link = URL / ObjectName;
						if (!bExists)
						{
							Version.Content.Add(*RemoteDataDescribe);
						}

						UE_LOG(LogOSSObjectStorageClient, Display, TEXT("Upload %s succeeded."), *FPaths::ConvertRelativePathToFull(NewPath));
					}
					else
					{
						UE_LOG(LogOSSObjectStorageClient, Error, TEXT("Upload %s fail."), *FPaths::ConvertRelativePathToFull(NewPath));
					}
				}
			};

			TArray<FString> PakPaths;
			IFileManager::Get().FindFilesRecursive(PakPaths, *PakLocalPaths, TEXT("*"), true, false);
		
			for (const auto& Tmp : PakPaths)
			{
				UpdateNewData(Tmp);
			}

			if (OSSObjectStorageClientMethod::PutServerVersion(Bucket, ServerVersionName, Platform, Version))
			{
				UE_LOG(LogOSSObjectStorageClient, Display, TEXT("Upload %s succeeded."), *Bucket);
			}
			else
			{
				UE_LOG(LogOSSObjectStorageClient, Error, TEXT("Upload %s fail."), *Bucket);
			}
		}
	}
	else
	{
		UE_LOG(LogOSSObjectStorageClient, Error, TEXT("%s Bucket does not exist."), *Bucket);
	}

	FEngineLoop::AppExit();
	return 0;
}
